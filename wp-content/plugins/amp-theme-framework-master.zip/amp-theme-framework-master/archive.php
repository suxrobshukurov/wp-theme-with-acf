
<?php amp_header() ?>

<?php amp_archive_title(); ?>
<?php amp_loop_template(); ?>

<?php amp_footer()?>