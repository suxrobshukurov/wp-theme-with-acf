# AMP Theme Framework

[logo]: https://ampforwp.com/wp-content/uploads/2017/09/amp-theme-framework-logo.png 

AMP Theme Framework - Create themes on AMP. https://ampforwp.com/amp-theme-framework/

## How to Create theme for AMP
Documentation - https://ampforwp.com/amp-theme-framework/#docs

Getting Started with AMP Themes -  https://ampforwp.com/tutorials/article/getting-started-amp-framework/
